package AWS_Classes.Dynamo;

/**
 * Created by Niko on 11/10/2015.
 */
public interface AsyncResponse {
        void processFinish(Vocab output);
}
